package projectBank;

public class Transaction 

{
	int transNum;
	String transdate;
	String transType;
	float amount;
	
	/**
	 * 
	 * @param tn transaction name
	 * @param td transaction date
	 * @param ttp transaction type
	 * @param amount transaction info 
	 */
	public Transaction(int tn, String td, String ttp, float amount)
	{
		transNum = tn;
		transdate = td;
		transType = ttp;
		this.amount = amount;
		
	}

	public int getTransNum() 
	{
		return transNum;
	}

	public String getTransdate() {
		return transdate;
	}

	public String getTransType() {
		return transType;
	}

	public float getAmount() {
		return amount;
	}

}
