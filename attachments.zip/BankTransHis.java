package projectBank;

import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

public class BankTransHis 

{
	enum Menu {MAIN, TH};
	boolean running;
	Scanner input;
	Calendar cal;
	Menu menu;
	Database db;
	public BankTransHis() throws ClassNotFoundException, SQLException
	{
		input = new Scanner(System.in);
		db = new Database();
	}
	public static void main (String[] args) throws ClassNotFoundException, SQLException
	{
		
//		Database db = new Database();
//		List<Transaction> transTrack = db.betweenDates("2016-04-13","2016-03-01");
//		
//		for (Transaction tra : transTrack)
//		{
//			System.out.println("Transaction #: " + tra.getTransNum()+ "\tTransaction Date: " + tra.getTransdate());
//			
//		}
//		
//		db.closeDb();
		
		
		new BankTransHis().run();
	}
	
	public void run()
	{
		 running = true;
		 menu = menu.MAIN;
		while (running)
		{
		
		
		switch(menu)
		{
		case MAIN:
			System.out.println("Press t for transaction hitory: \n");
			System.out.println("Press q to quit \n" );
			String st = input.nextLine();
			if (st.equalsIgnoreCase("t"))
			{
				menu = menu.TH;
				cal = Calendar.getInstance();
				
			}
			
			else if (st.equalsIgnoreCase("q"))
			{
				running = false;
			}
			
			else 
				System.out.println("Unrecognized input. Please enter a valid input.\n");
			
			break;
		case TH:
			transHisMenu();
			
			break;
			
			
		default:
			break;
		
		}
		
		}
		
		db.closeDb();
		input.close();
	}
	
	private void transHisMenu()
	{
		System.out.println("Transaction History: \n");
		System.out.println("Enter B to go back to the main menu:\n");
		System.out.println("Enter P for previous 10 days transactions: \n");
		DateFormat df  = new SimpleDateFormat("yyyy-MM-dd");
		String closerDate = df.format(cal.getTime());
		cal.add(Calendar.DAY_OF_YEAR, -10);
		
		String furtherDate = df.format(cal.getTime());
		cal.add(Calendar.DAY_OF_YEAR, 10);
		List <Transaction> trans2 = db.betweenDates(closerDate, furtherDate);
		System.out.println("------Transaction History---------------");
		System.out.println("Transaction # \tTransaction Date \tTransaction Type \tAmount");
		System.out.println("---------------------------------------------------------------");
		for (Transaction tns : trans2)
		{
			System.out.println(tns.getTransNum() + "\t"+ tns.getTransdate()+ "\t"+ tns.getTransType()+ "\t" + tns.getAmount());
			
		}
		
		String st = input.nextLine();
		if (st.equalsIgnoreCase("b"))
		{
			menu = menu.MAIN;
		}
		
		else if (st.equalsIgnoreCase("P"))
		{
			cal.add(Calendar.DAY_OF_YEAR, -10);
		}
		else 
			System.out.println("Unrecognized input. Please enter a valid input.\n");
			
	}

}
