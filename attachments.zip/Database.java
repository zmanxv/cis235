package projectBank;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;

//import com.mysql.jdbc.Connection;

public class Database 

{
	private Connection con;
	public Database() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
	}

	public List <Transaction> betweenDates(String closerDate, String furtherDate)
	{
		Statement st = null;
		
		ResultSet rs = null;
		
		List <Transaction > trans1 = new LinkedList<Transaction> ();
		try {
			st = con.createStatement();
			String sql = "select * from tranhistory where transdate<=\"" +closerDate +"\" and transdate>=\"" +furtherDate + "\" ;";
			rs = st.executeQuery(sql);
			while (rs.next())
			{
				int transNum = rs.getInt("trnsNum");
				String date = rs.getString("transdate");
				String tranType = rs.getString("transType");
				float amt = rs.getFloat("amount");
				
				Transaction tran = new Transaction(transNum, date, tranType, amt);
				trans1.add(tran);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return trans1;
		
	}
	
	public void closeDb()
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}


